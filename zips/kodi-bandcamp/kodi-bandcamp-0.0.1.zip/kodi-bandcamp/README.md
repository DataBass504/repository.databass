# kodi-bandcamp
It is a fork of https://gitlab.com/thesebas/kodi-bandcamp
hosted on https://github.com/wallon-ines/kodi-bandcamp.git

Listen bandcamp music in Kodi

# Install
* Download zip file 
* Install zip file in "Settings -> Add-ons -> Install from zip file -> Navigate to the ZIP file"
