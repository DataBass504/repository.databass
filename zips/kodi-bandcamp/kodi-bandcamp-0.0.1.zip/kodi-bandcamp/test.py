__author__ = 'thesebas'

import resources.lib.bc as bc
# print bc.get_collection('thesebas')
# print bc.get_wishlist('thesebas')
# for item in bc.get_search_results("pies"):
#     print item

# print bc.get_band_data_by_url('http://chipzel.co.uk/')
# print bc.get_band_data_by_url('http://chelseawolfe.bandcamp.com')

# print bc.get_band_music_by_url('http://chipzel.co.uk/')
#print bc.get_band_music_by_url('http://chelseawolfe.bandcamp.com')

print bc.get_album_tracks('https://chelseawolfe.bandcamp.com/album/abyss')
